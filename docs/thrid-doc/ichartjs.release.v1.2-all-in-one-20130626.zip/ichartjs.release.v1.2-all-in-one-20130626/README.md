ichartjs Library, release 1.2 (2013-06-26)
Licensed under the Apache License, Version 2.0 (the "License");
--------------------------------------------------
http://www.ichartjs.com
--------------------------------------------------
Directory INFO 

"dist" contains the packed js files
"docs" contains the ichartjs API docs
"minify" contains the minify js files
"samples" contains various demo
"src" contains the general javascript source files for the ichartjs
"test" contains the general javascript source files for test



